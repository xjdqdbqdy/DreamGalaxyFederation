import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, index } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * 用户游戏档案表：扩展用户表的游戏经济相关属性
 */
export const userGameProfiles = mysqlTable(
  "userGameProfiles",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 用户ID */
    userId: int("userId").notNull().unique(),
    /** 玩家在游戏中的昵称 */
    gameNickname: varchar("gameNickname", { length: 128 }),
    /** 玩家的总影响力评分 */
    totalInfluenceScore: decimal("totalInfluenceScore", { precision: 10, scale: 2 }).default("0").notNull(),
    /** 玩家的叙事张力等级（1-10） */
    narrativeTensionLevel: int("narrativeTensionLevel").default(1).notNull(),
    /** 玩家持有的资产总数 */
    totalAssetsHeld: int("totalAssetsHeld").default(0).notNull(),
    /** 玩家创建的资产总数 */
    totalAssetsCreated: int("totalAssetsCreated").default(0).notNull(),
    /** 玩家参与的交易总数 */
    totalTradesParticipated: int("totalTradesParticipated").default(0).notNull(),
    /** 玩家在各游戏节点的身份信息（JSON字符串） */
    crossGameIdentities: text("crossGameIdentities").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdx: index("userIdx").on(table.userId),
  })
);

export type UserGameProfile = typeof userGameProfiles.$inferSelect;
export type InsertUserGameProfile = typeof userGameProfiles.$inferInsert;

/**
 * 游戏节点表：代表主游戏（残梦银河）和子游戏
 * 每个节点是一个独立的游戏生态，可以与其他节点进行资产流转
 */
export const gameNodes = mysqlTable(
  "gameNodes",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 节点名称（如：残梦银河、星辰之塔等） */
    name: varchar("name", { length: 128 }).notNull(),
    /** 节点类型：主游戏或子游戏 */
    type: mysqlEnum("type", ["main", "sub"]).notNull(),
    /** 节点描述 */
    description: text("description"),
    /** 节点的当前Δ态秩序度（0-1） */
    orderLevel: decimal("orderLevel", { precision: 3, scale: 2 }).default("0.5").notNull(),
    /** 节点的当前Δ态混沌度（0-1） */
    chaosLevel: decimal("chaosLevel", { precision: 3, scale: 2 }).default("0.5").notNull(),
    /** 节点是否活跃 */
    isActive: boolean("isActive").default(true).notNull(),
    /** 父节点ID（用于子游戏关联主游戏） */
    parentNodeId: int("parentNodeId"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    parentIdx: index("parentIdx").on(table.parentNodeId),
  })
);

export type GameNode = typeof gameNodes.$inferSelect;
export type InsertGameNode = typeof gameNodes.$inferInsert;

/**
 * 因果资产表：代表可交易的游戏事件影响权
 * 资产的价值由其能改变的概率值和引发的后续事件总价值决定
 */
export const causalAssets = mysqlTable(
  "causalAssets",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 资产所有者的用户ID */
    ownerId: int("ownerId").notNull(),
    /** 资产所属的游戏节点 */
    gameNodeId: int("gameNodeId").notNull(),
    /** 资产名称 */
    name: varchar("name", { length: 256 }).notNull(),
    /** 资产描述 */
    description: text("description"),
    /** 资产能影响的事件哈希 */
    eventHash: varchar("eventHash", { length: 256 }).notNull(),
    /** 资产能改变的概率值（-1 到 +1） */
    probabilityShift: decimal("probabilityShift", { precision: 4, scale: 3 }).notNull(),
    /** 资产的当前市场价值（以主游戏货币计） */
    marketValue: decimal("marketValue", { precision: 18, scale: 8 }).default("0").notNull(),
    /** 资产的叙事张力等级（1-10） */
    narrativeTension: int("narrativeTension").default(5).notNull(),
    /** 资产是否已被交易过 */
    hasBeenTraded: boolean("hasBeenTraded").default(false).notNull(),
    /** 资产的创建事件描述 */
    originEventDescription: text("originEventDescription"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    ownerIdx: index("ownerIdx").on(table.ownerId),
    nodeIdx: index("nodeIdx").on(table.gameNodeId),
  })
);

export type CausalAsset = typeof causalAssets.$inferSelect;
export type InsertCausalAsset = typeof causalAssets.$inferInsert;

/**
 * 叙事事件表：记录游戏中发生的所有重要事件
 * 每个事件都可能影响概率场和资产价值
 */
export const narrativeEvents = mysqlTable(
  "narrativeEvents",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 事件所属的游戏节点 */
    gameNodeId: int("gameNodeId").notNull(),
    /** 触发事件的玩家ID */
    playerId: int("playerId").notNull(),
    /** 事件类型（如：asset_created, asset_traded, world_update等） */
    eventType: varchar("eventType", { length: 64 }).notNull(),
    /** 事件的叙事描述 */
    description: text("description").notNull(),
    /** 事件的张力等级（1-10） */
    tension: int("tension").default(5).notNull(),
    /** 事件影响的资产ID列表（JSON字符串） */
    affectedAssetIds: text("affectedAssetIds").notNull(),
    /** 事件对全局概率场的影响 */
    probabilityImpact: decimal("probabilityImpact", { precision: 4, scale: 3 }).default("0").notNull(),
    /** 事件的影响力评分（由系统计算） */
    influenceScore: decimal("influenceScore", { precision: 10, scale: 2 }).default("0").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    nodeIdx: index("nodeIdx").on(table.gameNodeId),
    playerIdx: index("playerIdx").on(table.playerId),
  })
);

export type NarrativeEvent = typeof narrativeEvents.$inferSelect;
export type InsertNarrativeEvent = typeof narrativeEvents.$inferInsert;

/**
 * 资产交易表：记录所有因果资产的交易历史
 * 每次交易本身也是一个叙事事件
 */
export const assetTrades = mysqlTable(
  "assetTrades",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 被交易的资产ID */
    assetId: int("assetId").notNull(),
    /** 卖方用户ID */
    sellerId: int("sellerId").notNull(),
    /** 买方用户ID */
    buyerId: int("buyerId"),
    /** 交易价格 */
    price: decimal("price", { precision: 18, scale: 8 }).notNull(),
    /** 交易状态：pending, completed, cancelled */
    status: mysqlEnum("status", ["pending", "completed", "cancelled"]).default("pending").notNull(),
    /** 交易是否是挂单（未完成） */
    isListing: boolean("isListing").default(false).notNull(),
    /** 交易产生的叙事事件ID */
    narrativeEventId: int("narrativeEventId"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  (table) => ({
    assetIdx: index("assetIdx").on(table.assetId),
    sellerIdx: index("sellerIdx").on(table.sellerId),
    buyerIdx: index("buyerIdx").on(table.buyerId),
  })
);

export type AssetTrade = typeof assetTrades.$inferSelect;
export type InsertAssetTrade = typeof assetTrades.$inferInsert;

/**
 * 概率场状态表：记录全局概率场的演化历史
 * 用于追踪世界的Δ态变化
 */
export const probabilityFieldStates = mysqlTable(
  "probabilityFieldStates",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 所属游戏节点 */
    gameNodeId: int("gameNodeId").notNull(),
    /** 当前的全局秩序度 */
    globalOrder: decimal("globalOrder", { precision: 3, scale: 2 }).default("0.5").notNull(),
    /** 当前的全局混沌度 */
    globalChaos: decimal("globalChaos", { precision: 3, scale: 2 }).default("0.5").notNull(),
    /** 当前的全局可能性 */
    globalPotential: decimal("globalPotential", { precision: 3, scale: 2 }).default("0.5").notNull(),
    /** 触发此状态更新的事件ID */
    triggeringEventId: int("triggeringEventId"),
    /** 状态快照（JSON字符串格式的详细数据） */
    snapshot: text("snapshot").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    nodeIdx: index("nodeIdx").on(table.gameNodeId),
  })
);

export type ProbabilityFieldState = typeof probabilityFieldStates.$inferSelect;
export type InsertProbabilityFieldState = typeof probabilityFieldStates.$inferInsert;

/**
 * 玩家影响力历史表：追踪每个玩家的影响力评分变化
 */
export const playerInfluenceHistory = mysqlTable(
  "playerInfluenceHistory",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 玩家用户ID */
    playerId: int("playerId").notNull(),
    /** 所属游戏节点 */
    gameNodeId: int("gameNodeId").notNull(),
    /** 影响力评分 */
    influenceScore: decimal("influenceScore", { precision: 10, scale: 2 }).notNull(),
    /** 影响力来源事件ID */
    sourceEventId: int("sourceEventId"),
    /** 影响力变化的原因 */
    reason: varchar("reason", { length: 256 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    playerIdx: index("playerIdx").on(table.playerId),
    nodeIdx: index("nodeIdx").on(table.gameNodeId),
  })
);

export type PlayerInfluenceHistory = typeof playerInfluenceHistory.$inferSelect;
export type InsertPlayerInfluenceHistory = typeof playerInfluenceHistory.$inferInsert;

/**
 * 治理提案表：记录社区提出的规则更新提案
 */
export const governanceProposals = mysqlTable(
  "governanceProposals",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 提案创建者 */
    proposerId: int("proposerId").notNull(),
    /** 提案所属游戏节点 */
    gameNodeId: int("gameNodeId").notNull(),
    /** 提案标题 */
    title: varchar("title", { length: 256 }).notNull(),
    /** 提案描述 */
    description: text("description").notNull(),
    /** 提案类型：rule_update, parameter_adjustment, feature_addition等 */
    proposalType: varchar("proposalType", { length: 64 }).notNull(),
    /** 提案状态：voting, approved, rejected, implemented */
    status: mysqlEnum("status", ["voting", "approved", "rejected", "implemented"]).default("voting").notNull(),
    /** 赞成票数 */
    votesFor: int("votesFor").default(0).notNull(),
    /** 反对票数 */
    votesAgainst: int("votesAgainst").default(0).notNull(),
    /** 投票截止时间 */
    votingDeadline: timestamp("votingDeadline").notNull(),
    /** 提案的规则变更内容（JSON字符串） */
    ruleChanges: text("ruleChanges").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    implementedAt: timestamp("implementedAt"),
  },
  (table) => ({
    proposerIdx: index("proposerIdx").on(table.proposerId),
    nodeIdx: index("nodeIdx").on(table.gameNodeId),
  })
);

export type GovernanceProposal = typeof governanceProposals.$inferSelect;
export type InsertGovernanceProposal = typeof governanceProposals.$inferInsert;

/**
 * 治理投票表：记录玩家对治理提案的投票
 */
export const governanceVotes = mysqlTable(
  "governanceVotes",
  {
    id: int("id").autoincrement().primaryKey(),
    /** 提案ID */
    proposalId: int("proposalId").notNull(),
    /** 投票者用户ID */
    voterId: int("voterId").notNull(),
    /** 投票选择：for, against */
    vote: mysqlEnum("vote", ["for", "against"]).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    proposalIdx: index("proposalIdx").on(table.proposalId),
    voterIdx: index("voterIdx").on(table.voterId),
  })
);

export type GovernanceVote = typeof governanceVotes.$inferSelect;
export type InsertGovernanceVote = typeof governanceVotes.$inferInsert;

/**
 * 关系定义
 */
export const usersRelations = relations(users, ({ many, one }) => ({
  gameProfile: one(userGameProfiles),
  causalAssets: many(causalAssets),
  narrativeEvents: many(narrativeEvents),
  assetTradesSold: many(assetTrades, { relationName: "seller" }),
  assetTradesBought: many(assetTrades, { relationName: "buyer" }),
  influenceHistory: many(playerInfluenceHistory),
  proposals: many(governanceProposals),
  votes: many(governanceVotes),
}));

export const gameNodesRelations = relations(gameNodes, ({ many, one }) => ({
  causalAssets: many(causalAssets),
  narrativeEvents: many(narrativeEvents),
  probabilityStates: many(probabilityFieldStates),
  influenceHistory: many(playerInfluenceHistory),
  proposals: many(governanceProposals),
  parentNode: one(gameNodes, {
    fields: [gameNodes.parentNodeId],
    references: [gameNodes.id],
    relationName: "parent",
  }),
  childNodes: many(gameNodes, { relationName: "parent" }),
}));

export const causalAssetsRelations = relations(causalAssets, ({ one, many }) => ({
  owner: one(users, {
    fields: [causalAssets.ownerId],
    references: [users.id],
  }),
  gameNode: one(gameNodes, {
    fields: [causalAssets.gameNodeId],
    references: [gameNodes.id],
  }),
  trades: many(assetTrades),
}));

export const narrativeEventsRelations = relations(narrativeEvents, ({ one, many }) => ({
  player: one(users, {
    fields: [narrativeEvents.playerId],
    references: [users.id],
  }),
  gameNode: one(gameNodes, {
    fields: [narrativeEvents.gameNodeId],
    references: [gameNodes.id],
  }),
  trades: many(assetTrades),
}));

export const assetTradesRelations = relations(assetTrades, ({ one }) => ({
  asset: one(causalAssets, {
    fields: [assetTrades.assetId],
    references: [causalAssets.id],
  }),
  seller: one(users, {
    fields: [assetTrades.sellerId],
    references: [users.id],
    relationName: "seller",
  }),
  buyer: one(users, {
    fields: [assetTrades.buyerId],
    references: [users.id],
    relationName: "buyer",
  }),
  narrativeEvent: one(narrativeEvents, {
    fields: [assetTrades.narrativeEventId],
    references: [narrativeEvents.id],
  }),
}));

export const probabilityFieldStatesRelations = relations(probabilityFieldStates, ({ one }) => ({
  gameNode: one(gameNodes, {
    fields: [probabilityFieldStates.gameNodeId],
    references: [gameNodes.id],
  }),
  triggeringEvent: one(narrativeEvents, {
    fields: [probabilityFieldStates.triggeringEventId],
    references: [narrativeEvents.id],
  }),
}));

export const playerInfluenceHistoryRelations = relations(playerInfluenceHistory, ({ one }) => ({
  player: one(users, {
    fields: [playerInfluenceHistory.playerId],
    references: [users.id],
  }),
  gameNode: one(gameNodes, {
    fields: [playerInfluenceHistory.gameNodeId],
    references: [gameNodes.id],
  }),
  sourceEvent: one(narrativeEvents, {
    fields: [playerInfluenceHistory.sourceEventId],
    references: [narrativeEvents.id],
  }),
}));

export const governanceProposalsRelations = relations(governanceProposals, ({ one, many }) => ({
  proposer: one(users, {
    fields: [governanceProposals.proposerId],
    references: [users.id],
  }),
  gameNode: one(gameNodes, {
    fields: [governanceProposals.gameNodeId],
    references: [gameNodes.id],
  }),
  votes: many(governanceVotes),
}));

export const governanceVotesRelations = relations(governanceVotes, ({ one }) => ({
  proposal: one(governanceProposals, {
    fields: [governanceVotes.proposalId],
    references: [governanceProposals.id],
  }),
  voter: one(users, {
    fields: [governanceVotes.voterId],
    references: [users.id],
  }),
}));

export const userGameProfilesRelations = relations(userGameProfiles, ({ one }) => ({
  user: one(users, {
    fields: [userGameProfiles.userId],
    references: [users.id],
  }),
}));
