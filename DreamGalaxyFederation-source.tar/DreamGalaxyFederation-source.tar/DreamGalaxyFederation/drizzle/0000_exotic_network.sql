CREATE TABLE `assetTrades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assetId` int NOT NULL,
	`sellerId` int NOT NULL,
	`buyerId` int,
	`price` decimal(18,8) NOT NULL,
	`status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
	`isListing` boolean NOT NULL DEFAULT false,
	`narrativeEventId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `assetTrades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `causalAssets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`gameNodeId` int NOT NULL,
	`name` varchar(256) NOT NULL,
	`description` text,
	`eventHash` varchar(256) NOT NULL,
	`probabilityShift` decimal(4,3) NOT NULL,
	`marketValue` decimal(18,8) NOT NULL DEFAULT '0',
	`narrativeTension` int NOT NULL DEFAULT 5,
	`hasBeenTraded` boolean NOT NULL DEFAULT false,
	`originEventDescription` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `causalAssets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameNodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`type` enum('main','sub') NOT NULL,
	`description` text,
	`orderLevel` decimal(3,2) NOT NULL DEFAULT '0.5',
	`chaosLevel` decimal(3,2) NOT NULL DEFAULT '0.5',
	`isActive` boolean NOT NULL DEFAULT true,
	`parentNodeId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gameNodes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `governanceProposals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`proposerId` int NOT NULL,
	`gameNodeId` int NOT NULL,
	`title` varchar(256) NOT NULL,
	`description` text NOT NULL,
	`proposalType` varchar(64) NOT NULL,
	`status` enum('voting','approved','rejected','implemented') NOT NULL DEFAULT 'voting',
	`votesFor` int NOT NULL DEFAULT 0,
	`votesAgainst` int NOT NULL DEFAULT 0,
	`votingDeadline` timestamp NOT NULL,
	`ruleChanges` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`implementedAt` timestamp,
	CONSTRAINT `governanceProposals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `governanceVotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`proposalId` int NOT NULL,
	`voterId` int NOT NULL,
	`vote` enum('for','against') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `governanceVotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `narrativeEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameNodeId` int NOT NULL,
	`playerId` int NOT NULL,
	`eventType` varchar(64) NOT NULL,
	`description` text NOT NULL,
	`tension` int NOT NULL DEFAULT 5,
	`affectedAssetIds` text NOT NULL,
	`probabilityImpact` decimal(4,3) NOT NULL DEFAULT '0',
	`influenceScore` decimal(10,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `narrativeEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `playerInfluenceHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`playerId` int NOT NULL,
	`gameNodeId` int NOT NULL,
	`influenceScore` decimal(10,2) NOT NULL,
	`sourceEventId` int,
	`reason` varchar(256) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `playerInfluenceHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `probabilityFieldStates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameNodeId` int NOT NULL,
	`globalOrder` decimal(3,2) NOT NULL DEFAULT '0.5',
	`globalChaos` decimal(3,2) NOT NULL DEFAULT '0.5',
	`globalPotential` decimal(3,2) NOT NULL DEFAULT '0.5',
	`triggeringEventId` int,
	`snapshot` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `probabilityFieldStates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userGameProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameNickname` varchar(128),
	`totalInfluenceScore` decimal(10,2) NOT NULL DEFAULT '0',
	`narrativeTensionLevel` int NOT NULL DEFAULT 1,
	`totalAssetsHeld` int NOT NULL DEFAULT 0,
	`totalAssetsCreated` int NOT NULL DEFAULT 0,
	`totalTradesParticipated` int NOT NULL DEFAULT 0,
	`crossGameIdentities` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userGameProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `userGameProfiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `assetIdx` ON `assetTrades` (`assetId`);--> statement-breakpoint
CREATE INDEX `sellerIdx` ON `assetTrades` (`sellerId`);--> statement-breakpoint
CREATE INDEX `buyerIdx` ON `assetTrades` (`buyerId`);--> statement-breakpoint
CREATE INDEX `ownerIdx` ON `causalAssets` (`ownerId`);--> statement-breakpoint
CREATE INDEX `nodeIdx` ON `causalAssets` (`gameNodeId`);--> statement-breakpoint
CREATE INDEX `parentIdx` ON `gameNodes` (`parentNodeId`);--> statement-breakpoint
CREATE INDEX `proposerIdx` ON `governanceProposals` (`proposerId`);--> statement-breakpoint
CREATE INDEX `nodeIdx` ON `governanceProposals` (`gameNodeId`);--> statement-breakpoint
CREATE INDEX `proposalIdx` ON `governanceVotes` (`proposalId`);--> statement-breakpoint
CREATE INDEX `voterIdx` ON `governanceVotes` (`voterId`);--> statement-breakpoint
CREATE INDEX `nodeIdx` ON `narrativeEvents` (`gameNodeId`);--> statement-breakpoint
CREATE INDEX `playerIdx` ON `narrativeEvents` (`playerId`);--> statement-breakpoint
CREATE INDEX `playerIdx` ON `playerInfluenceHistory` (`playerId`);--> statement-breakpoint
CREATE INDEX `nodeIdx` ON `playerInfluenceHistory` (`gameNodeId`);--> statement-breakpoint
CREATE INDEX `nodeIdx` ON `probabilityFieldStates` (`gameNodeId`);--> statement-breakpoint
CREATE INDEX `userIdx` ON `userGameProfiles` (`userId`);