import { eq, or, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  gameNodes,
  causalAssets,
  narrativeEvents,
  assetTrades,
  userGameProfiles,
  playerInfluenceHistory,
  InsertNarrativeEvent,
  InsertAssetTrade,
  InsertUserGameProfile,
  InsertPlayerInfluenceHistory,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * 游戏节点查询
 */
export async function getGameNodeById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(gameNodes).where(eq(gameNodes.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllGameNodes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(gameNodes).where(eq(gameNodes.isActive, true));
}

/**
 * 因果资产查询
 */
export async function getCausalAssetById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(causalAssets).where(eq(causalAssets.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserAssets(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(causalAssets).where(eq(causalAssets.ownerId, userId));
}

export async function getNodeAssets(nodeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(causalAssets).where(eq(causalAssets.gameNodeId, nodeId));
}

/**
 * 叙事事件查询
 */
export async function createNarrativeEvent(event: InsertNarrativeEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(narrativeEvents).values(event);
  return result;
}

export async function getNodeEvents(nodeId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(narrativeEvents)
    .where(eq(narrativeEvents.gameNodeId, nodeId))
    .orderBy(desc(narrativeEvents.createdAt))
    .limit(limit);
}

/**
 * 资产交易查询
 */
export async function createAssetTrade(trade: InsertAssetTrade) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(assetTrades).values(trade);
}

export async function getUserTrades(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(assetTrades)
    .where(or(eq(assetTrades.sellerId, userId), eq(assetTrades.buyerId, userId)));
}

/**
 * 玩家档案查询
 */
export async function getUserGameProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userGameProfiles).where(eq(userGameProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateUserGameProfile(profile: InsertUserGameProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await getUserGameProfile(profile.userId);
  if (existing) {
    return db.update(userGameProfiles).set(profile).where(eq(userGameProfiles.userId, profile.userId));
  } else {
    return db.insert(userGameProfiles).values(profile);
  }
}

/**
 * 影响力历史查询
 */
export async function recordInfluenceChange(record: InsertPlayerInfluenceHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(playerInfluenceHistory).values(record);
}

export async function getPlayerInfluenceInNode(playerId: number, nodeId: number) {
  const db = await getDb();
  if (!db) return "0";
  const result = await db
    .select({ score: playerInfluenceHistory.influenceScore })
    .from(playerInfluenceHistory)
    .where(and(eq(playerInfluenceHistory.playerId, playerId), eq(playerInfluenceHistory.gameNodeId, nodeId)))
    .orderBy(desc(playerInfluenceHistory.createdAt))
    .limit(1);
  return result.length > 0 ? result[0].score.toString() : "0";
}

// TODO: add additional feature queries here as your schema grows.
