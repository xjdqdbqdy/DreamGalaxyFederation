import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

/**
 * 经济系统单元测试
 */

// 模拟认证用户上下文
function createAuthContext(userId: number = 1): TrpcContext {
  return {
    user: {
      id: userId,
      openId: `test-user-${userId}`,
      email: `test${userId}@example.com`,
      name: `Test User ${userId}`,
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Economy Router", () => {
  describe("gameNodes", () => {
    it("should list all active game nodes", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const nodes = await caller.economy.gameNodes.list();

      expect(Array.isArray(nodes)).toBe(true);
      expect(nodes.length).toBeGreaterThan(0);
      expect(nodes[0]).toHaveProperty("id");
      expect(nodes[0]).toHaveProperty("name");
      expect(nodes[0]).toHaveProperty("type");
    });

    it("should get game node by id", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      // 先获取所有节点
      const nodes = await caller.economy.gameNodes.list();
      expect(nodes.length).toBeGreaterThan(0);

      // 获取第一个节点的详情
      const nodeId = nodes[0].id;
      const node = await caller.economy.gameNodes.getById({ id: nodeId });

      expect(node).toHaveProperty("id", nodeId);
      expect(node).toHaveProperty("name");
      expect(node).toHaveProperty("orderLevel");
      expect(node).toHaveProperty("chaosLevel");
    });

    it("should get node assets", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const nodes = await caller.economy.gameNodes.list();
      expect(nodes.length).toBeGreaterThan(0);

      const assets = await caller.economy.gameNodes.getAssets({ nodeId: nodes[0].id });

      expect(Array.isArray(assets)).toBe(true);
    });

    it("should get node events", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const nodes = await caller.economy.gameNodes.list();
      expect(nodes.length).toBeGreaterThan(0);

      const events = await caller.economy.gameNodes.getEvents({
        nodeId: nodes[0].id,
        limit: 10,
      });

      expect(Array.isArray(events)).toBe(true);
    });
  });

  describe("causalAssets", () => {
    it("should get user assets", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const assets = await caller.economy.causalAssets.getUserAssets();

      expect(Array.isArray(assets)).toBe(true);
    });

    it("should create a new causal asset", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      // 获取一个游戏节点
      const nodes = await caller.economy.gameNodes.list();
      expect(nodes.length).toBeGreaterThan(0);

      const result = await caller.economy.causalAssets.create({
        gameNodeId: nodes[0].id,
        name: "Test Asset",
        description: "A test causal asset",
        eventHash: "test-event-hash-123",
        probabilityShift: 0.5,
        narrativeTension: 7,
        originEventDescription: "Created for testing",
      });

      expect(result).toBeDefined();
    });

    it("should throw error when creating asset with invalid node", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.economy.causalAssets.create({
          gameNodeId: 99999,
          name: "Invalid Asset",
          description: "This should fail",
          eventHash: "invalid-hash",
          probabilityShift: 0.5,
          narrativeTension: 5,
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("NOT_FOUND");
      }
    });
  });

  describe("influence", () => {
    it("should get player profile", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const profile = await caller.economy.influence.getProfile();

      expect(profile).toHaveProperty("userId");
      expect(profile).toHaveProperty("totalInfluenceScore");
      expect(profile).toHaveProperty("narrativeTensionLevel");
      expect(profile).toHaveProperty("totalAssetsHeld");
    });

    it("should update player nickname", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      // 先获取档案确保存在
      await caller.economy.influence.getProfile();

      // 更新昵称
      const result = await caller.economy.influence.updateNickname({
        nickname: "Dream Wanderer",
      });

      expect(result.success).toBe(true);

      // 验证更新
      const profile = await caller.economy.influence.getProfile();
      expect(profile.gameNickname).toBe("Dream Wanderer");
    });

    it("should get player influence in node", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const nodes = await caller.economy.gameNodes.list();
      expect(nodes.length).toBeGreaterThan(0);

      const influence = await caller.economy.influence.getPlayerInfluence({
        nodeId: nodes[0].id,
      });

      expect(typeof influence).toBe("string");
      expect(parseFloat(influence)).toBeGreaterThanOrEqual(0);
    });
  });

  describe("market", () => {
    it("should get user trades", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const trades = await caller.economy.market.getUserTrades();

      expect(Array.isArray(trades)).toBe(true);
    });

    it("should create a listing", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      // 先创建一个资产
      const nodes = await caller.economy.gameNodes.list();
      expect(nodes.length).toBeGreaterThan(0);

      await caller.economy.causalAssets.create({
        gameNodeId: nodes[0].id,
        name: "Tradeable Asset",
        description: "An asset for trading",
        eventHash: "trade-test-hash",
        probabilityShift: 0.3,
        narrativeTension: 6,
      });

      // 获取用户资产
      const assets = await caller.economy.causalAssets.getUserAssets();
      expect(assets.length).toBeGreaterThan(0);

      // 创建交易挂单
      const result = await caller.economy.market.createListing({
        assetId: assets[0].id,
        price: "100.50",
      });

      expect(result.success).toBe(true);
    });

    it("should throw error when listing non-owned asset", async () => {
      const ctx1 = createAuthContext(1);
      const ctx2 = createAuthContext(2);
      const caller1 = appRouter.createCaller(ctx1);
      const caller2 = appRouter.createCaller(ctx2);

      // 用户1创建资产
      const nodes = await caller1.economy.gameNodes.list();
      expect(nodes.length).toBeGreaterThan(0);

      await caller1.economy.causalAssets.create({
        gameNodeId: nodes[0].id,
        name: "User1 Asset",
        description: "Owned by user 1",
        eventHash: "user1-asset-hash",
        probabilityShift: 0.4,
        narrativeTension: 5,
      });

      const user1Assets = await caller1.economy.causalAssets.getUserAssets();
      expect(user1Assets.length).toBeGreaterThan(0);

      // 用户2尝试交易用户1的资产
      try {
        await caller2.economy.market.createListing({
          assetId: user1Assets[0].id,
          price: "50.00",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });
});
