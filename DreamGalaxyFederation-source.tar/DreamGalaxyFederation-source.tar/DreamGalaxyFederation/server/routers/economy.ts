import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  getCausalAssetById,
  getUserAssets,
  getNodeAssets,
  createNarrativeEvent,
  getNodeEvents,
  createAssetTrade,
  getUserTrades,
  getUserGameProfile,
  createOrUpdateUserGameProfile,
  recordInfluenceChange,
  getPlayerInfluenceInNode,
  getGameNodeById,
  getAllGameNodes,
  getDb,
} from "../db";
import { causalAssets } from "../../drizzle/schema";
import { TRPCError } from "@trpc/server";


/**
 * 经济系统路由
 * 包含因果资产、交易市场、影响力评分等核心功能
 */
export const economyRouter = router({
  /**
   * 游戏节点管理
   */
  gameNodes: router({
    /**获取所有活跃游戏节点 */
    list: publicProcedure.query(async () => {
      return getAllGameNodes();
    }),

    /**获取单个游戏节点详情 */
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const node = await getGameNodeById(input.id);
      if (!node) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Game node not found" });
      }
      return node;
    }),

    /**获取节点内的所有资产 */
    getAssets: publicProcedure.input(z.object({ nodeId: z.number() })).query(async ({ input }) => {
      return getNodeAssets(input.nodeId);
    }),

    /**获取节点的叙事事件 */
    getEvents: publicProcedure
      .input(z.object({ nodeId: z.number(), limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return getNodeEvents(input.nodeId, input.limit);
      }),
  }),

  /**
   * 因果资产管理
   */
  causalAssets: router({
    /**获取单个资产详情 */
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const asset = await getCausalAssetById(input.id);
      if (!asset) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Asset not found" });
      }
      return asset;
    }),

    /**获取玩家持有的所有资产 */
    getUserAssets: protectedProcedure.query(async ({ ctx }) => {
      return getUserAssets(ctx.user.id);
    }),

    /**创建新的因果资产 */
    create: protectedProcedure
      .input(
        z.object({
          gameNodeId: z.number(),
          name: z.string().min(1).max(256),
          description: z.string().optional(),
          eventHash: z.string(),
          probabilityShift: z.number().min(-1).max(1),
          narrativeTension: z.number().int().min(1).max(10).default(5),
          originEventDescription: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // 验证游戏节点存在
        const node = await getGameNodeById(input.gameNodeId);
        if (!node) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Game node not found" });
        }

        // 创建资产
        const dbInstance = await getDb();
        if (!dbInstance) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
        }

        // 插入资产
        const result = await dbInstance.insert(causalAssets).values({
          ownerId: ctx.user.id,
          gameNodeId: input.gameNodeId,
          name: input.name,
          description: input.description,
          eventHash: input.eventHash,
          probabilityShift: String(input.probabilityShift),
          narrativeTension: input.narrativeTension,
          originEventDescription: input.originEventDescription,
        });

        // 创建叙事事件记录
        await createNarrativeEvent({
          gameNodeId: input.gameNodeId,
          playerId: ctx.user.id,
          eventType: "asset_created",
          description: `玩家创建了资产: ${input.name}`,
          tension: input.narrativeTension,
          affectedAssetIds: JSON.stringify([]),
          probabilityImpact: String(input.probabilityShift) as any,
          influenceScore: String(input.narrativeTension * 10) as any,
        });

        // 更新玩家档案
        const profile = await getUserGameProfile(ctx.user.id);
        if (profile) {
          await createOrUpdateUserGameProfile({
            userId: ctx.user.id,
            totalAssetsCreated: (profile.totalAssetsCreated || 0) + 1,
            crossGameIdentities: profile.crossGameIdentities,
          } as any);
        }

        return result;
      }),
  }),

  /**
   * 资产交易市场
   */
  market: router({
    /**获取玩家的交易历史 */
    getUserTrades: protectedProcedure.query(async ({ ctx }) => {
      return getUserTrades(ctx.user.id);
    }),

    /**创建交易挂单 */
    createListing: protectedProcedure
      .input(
        z.object({
          assetId: z.number(),
          price: z.string(), // 使用字符串以支持大数字
        })
      )
      .mutation(async ({ ctx, input }) => {
        // 验证资产存在且属于用户
        const asset = await getCausalAssetById(input.assetId);
        if (!asset) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Asset not found" });
        }
        if (asset.ownerId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN", message: "You do not own this asset" });
        }

        // 创建交易记录
        await createAssetTrade({
          assetId: input.assetId,
          sellerId: ctx.user.id,
          price: String(input.price),
          status: "pending",
          isListing: true,
        });

        return { success: true };
      }),

    /**完成交易 */
    completeTrade: protectedProcedure
      .input(
        z.object({
          tradeId: z.number(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // TODO: 实现交易完成逻辑
        return { success: true };
      }),
  }),

  /**
   * 玩家影响力系统
   */
  influence: router({
    /**获取玩家在特定节点的影响力评分 */
    getPlayerInfluence: protectedProcedure
      .input(z.object({ nodeId: z.number() }))
      .query(async ({ ctx, input }) => {
        return getPlayerInfluenceInNode(ctx.user.id, input.nodeId);
      }),

    /**获取玩家档案 */
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      let profile = await getUserGameProfile(ctx.user.id);
      if (!profile) {
        // 创建新档案
        await createOrUpdateUserGameProfile({
          userId: ctx.user.id,
          gameNickname: ctx.user.name || "Anonymous",
          totalInfluenceScore: "0" as any,
          narrativeTensionLevel: 1,
          totalAssetsHeld: 0,
          totalAssetsCreated: 0,
          totalTradesParticipated: 0,
          crossGameIdentities: JSON.stringify({}),
        });
        profile = await getUserGameProfile(ctx.user.id);
      }
      return profile;
    }),

    /**更新玩家昵称 */
    updateNickname: protectedProcedure
      .input(z.object({ nickname: z.string().min(1).max(128) }))
      .mutation(async ({ ctx, input }) => {
        const profile = await getUserGameProfile(ctx.user.id);
        if (!profile) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Player profile not found" });
        }

        await createOrUpdateUserGameProfile({
          userId: ctx.user.id,
          gameNickname: input.nickname,
          crossGameIdentities: profile.crossGameIdentities,
        } as any);

        return { success: true };
      }),
  }),
});
