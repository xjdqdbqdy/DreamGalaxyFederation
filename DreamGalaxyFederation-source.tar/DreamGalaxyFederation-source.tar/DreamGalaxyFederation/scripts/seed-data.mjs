/**
 * 数据初始化脚本
 * 为残梦银河游戏联邦体添加示例数据
 */

import mysql from "mysql2/promise";
import dotenv from "dotenv";
import https from "https";

dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error("DATABASE_URL environment variable is not set");
  process.exit(1);
}

// 解析数据库连接字符串
const url = new URL(DATABASE_URL);
const config = {
  host: url.hostname,
  user: url.username,
  password: url.password,
  database: url.pathname.slice(1),
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  ssl: {
    rejectUnauthorized: false,
  },
};

async function seedData() {
  // 禁用Node.js的SSL证书验证
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  const connection = await mysql.createConnection(config);

  try {
    console.log("开始初始化数据...");

    // 1. 创建主游戏节点
    await connection.execute(
      `INSERT INTO gameNodes (name, type, description, orderLevel, chaosLevel, isActive) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        "残梦银河",
        "main",
        "跨游戏经济宇宙的中心节点，所有子游戏的经济循环枢纽",
        0.7,
        0.3,
        true,
      ]
    );

    // 获取主游戏节点ID
    const [mainNodes] = await connection.execute(
      `SELECT id FROM gameNodes WHERE name = '残梦银河' LIMIT 1`
    );
    const mainNodeId = mainNodes[0]?.id;

    console.log(`✓ 创建主游戏节点: 残梦银河 (ID: ${mainNodeId})`);

    // 2. 创建子游戏节点
    const subGames = [
      {
        name: "星辰之塔",
        description: "一个充满神秘力量的高塔，每层都代表不同的现实可能性",
        orderLevel: 0.6,
        chaosLevel: 0.4,
      },
      {
        name: "深渊回响",
        description: "深邃的地下世界，充满了古老的秘密和隐藏的财宝",
        orderLevel: 0.5,
        chaosLevel: 0.5,
      },
      {
        name: "晨曦平原",
        description: "广阔的平原上，无数玩家进行着经济交易和资产流转",
        orderLevel: 0.75,
        chaosLevel: 0.25,
      },
      {
        name: "梦境碎片",
        description: "由玩家的集体意识构成的虚幻世界，规则不断演变",
        orderLevel: 0.4,
        chaosLevel: 0.6,
      },
    ];

    for (const game of subGames) {
      await connection.execute(
        `INSERT INTO gameNodes (name, type, description, orderLevel, chaosLevel, isActive, parentNodeId) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [game.name, "sub", game.description, game.orderLevel, game.chaosLevel, true, mainNodeId]
      );
      console.log(`✓ 创建子游戏节点: ${game.name}`);
    }

    // 3. 创建概率场状态
    await connection.execute(
      `INSERT INTO probabilityFieldStates (gameNodeId, globalOrder, globalChaos, globalPotential, snapshot) 
       VALUES (?, ?, ?, ?, ?)`,
      [mainNodeId, 0.5, 0.5, 0.5, JSON.stringify({ initialized: true })]
    );

    console.log("✓ 初始化全局概率场");

    console.log("\n✅ 数据初始化完成！");
    console.log(`已创建 1 个主游戏节点和 ${subGames.length} 个子游戏节点`);
  } catch (error) {
    console.error("数据初始化失败:", error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

seedData();
