import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Loader2, Sparkles, TrendingUp, Zap } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

/**
 * 玩家仪表盘
 * 显示玩家的资产、交易历史、影响力等信息
 */
export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // 重定向未认证用户
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/");
    }
  }, [isAuthenticated, navigate]);

  const profileQuery = trpc.economy.influence.getProfile.useQuery();
  const assetsQuery = trpc.economy.causalAssets.getUserAssets.useQuery();
  const tradesQuery = trpc.economy.market.getUserTrades.useQuery();

  if (!isAuthenticated) {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* 页面标题 */}
        <div>
          <h1 className="text-3xl font-bold text-slate-100">玩家仪表盘</h1>
          <p className="text-slate-400 mt-2">
            管理您的资产、查看交易历史和影响力评分
          </p>
        </div>

        {/* 统计卡片 */}
        {profileQuery.data && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-purple-400" />
                  总影响力评分
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-400">
                  {profileQuery.data.totalInfluenceScore}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-pink-400" />
                  持有资产数
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-pink-400">
                  {profileQuery.data.totalAssetsHeld}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  创建资产数
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-400">
                  {profileQuery.data.totalAssetsCreated}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  叙事张力等级
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-cyan-400">
                  {profileQuery.data.narrativeTensionLevel}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 标签页内容 */}
        <Tabs defaultValue="assets" className="w-full">
          <TabsList className="bg-slate-800/50 border border-purple-500/20">
            <TabsTrigger value="assets">我的资产</TabsTrigger>
            <TabsTrigger value="trades">交易历史</TabsTrigger>
            <TabsTrigger value="profile">个人档案</TabsTrigger>
          </TabsList>

          {/* 资产标签页 */}
          <TabsContent value="assets" className="space-y-4">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle>我的因果资产</CardTitle>
                <CardDescription>您持有的所有游戏事件影响权</CardDescription>
              </CardHeader>
              <CardContent>
                {assetsQuery.isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-purple-400" />
                  </div>
                ) : assetsQuery.data && assetsQuery.data.length > 0 ? (
                  <div className="space-y-4">
                    {assetsQuery.data.map((asset) => (
                      <div
                        key={asset.id}
                        className="p-4 bg-slate-700/50 rounded-lg border border-purple-500/20 hover:border-purple-500/50 transition-colors"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-semibold text-purple-300">{asset.name}</h4>
                            <p className="text-sm text-slate-400 mt-1">{asset.description}</p>
                          </div>
                          <span className="px-2 py-1 bg-purple-500/20 text-purple-300 text-xs rounded-full">
                            {asset.narrativeTension}/10
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-4 mt-3 text-sm">
                          <div>
                            <div className="text-slate-400">概率影响</div>
                            <div className="text-purple-400 font-semibold">
                              {parseFloat(asset.probabilityShift as any).toFixed(3)}
                            </div>
                          </div>
                          <div>
                            <div className="text-slate-400">市场价值</div>
                            <div className="text-pink-400 font-semibold">
                              {parseFloat(asset.marketValue as any).toFixed(2)}
                            </div>
                          </div>
                          <div>
                            <div className="text-slate-400">状态</div>
                            <div className="text-cyan-400 font-semibold">
                              {asset.hasBeenTraded ? "已交易" : "未交易"}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-400">
                    您还没有任何资产。创建一个新的因果资产来开始吧！
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* 交易标签页 */}
          <TabsContent value="trades" className="space-y-4">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle>交易历史</CardTitle>
                <CardDescription>您的所有资产交易记录</CardDescription>
              </CardHeader>
              <CardContent>
                {tradesQuery.isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-purple-400" />
                  </div>
                ) : tradesQuery.data && tradesQuery.data.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-purple-500/20">
                          <th className="text-left py-3 px-4 text-slate-300">资产ID</th>
                          <th className="text-left py-3 px-4 text-slate-300">交易价格</th>
                          <th className="text-left py-3 px-4 text-slate-300">角色</th>
                          <th className="text-left py-3 px-4 text-slate-300">状态</th>
                          <th className="text-left py-3 px-4 text-slate-300">时间</th>
                        </tr>
                      </thead>
                      <tbody>
                        {tradesQuery.data.map((trade) => (
                          <tr
                            key={trade.id}
                            className="border-b border-purple-500/10 hover:bg-slate-700/30 transition-colors"
                          >
                            <td className="py-3 px-4 text-purple-400">#{trade.assetId}</td>
                            <td className="py-3 px-4 text-pink-400">
                              {parseFloat(trade.price as any).toFixed(2)}
                            </td>
                            <td className="py-3 px-4 text-slate-300">
                              {trade.sellerId === user?.id ? "卖方" : "买方"}
                            </td>
                            <td className="py-3 px-4">
                              <span
                                className={`px-2 py-1 rounded text-xs font-semibold ${
                                  trade.status === "completed"
                                    ? "bg-green-500/20 text-green-300"
                                    : trade.status === "pending"
                                      ? "bg-yellow-500/20 text-yellow-300"
                                      : "bg-red-500/20 text-red-300"
                                }`}
                              >
                                {trade.status === "completed"
                                  ? "已完成"
                                  : trade.status === "pending"
                                    ? "待处理"
                                    : "已取消"}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-slate-400">
                              {new Date(trade.createdAt).toLocaleDateString("zh-CN")}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-400">
                    暂无交易记录
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* 个人档案标签页 */}
          <TabsContent value="profile" className="space-y-4">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle>个人档案</CardTitle>
                <CardDescription>您的跨游戏身份信息</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-slate-400">游戏昵称</label>
                    <p className="text-lg font-semibold text-purple-300 mt-1">
                      {profileQuery.data?.gameNickname || "未设置"}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-slate-400">账户名称</label>
                    <p className="text-lg font-semibold text-purple-300 mt-1">
                      {user?.name || "Anonymous"}
                    </p>
                  </div>
                </div>
                <div className="pt-4 border-t border-purple-500/20">
                  <label className="text-sm text-slate-400">跨游戏身份</label>
                  <p className="text-slate-300 mt-2">
                    您在各个游戏节点中的身份信息将在这里显示
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
