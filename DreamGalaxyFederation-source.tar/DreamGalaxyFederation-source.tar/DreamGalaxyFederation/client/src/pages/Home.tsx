import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Loader2, Sparkles, Zap, Users, TrendingUp } from "lucide-react";
import { Link } from "wouter";

/**
 * 残梦银河游戏联邦体 - 首页
 * 展示游戏经济系统概览、游戏节点和玩家信息
 */
export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const gameNodesQuery = trpc.economy.gameNodes.list.useQuery();
  const playerProfileQuery = trpc.economy.influence.getProfile.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* 导航栏 */}
      <nav className="border-b border-purple-500/20 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-purple-400" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              残梦银河联邦体
            </h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-slate-300">
                  欢迎, <span className="text-purple-400 font-semibold">{user?.name}</span>
                </span>
                <Link href="/dashboard">
                  <Button variant="outline" size="sm">
                    仪表盘
                  </Button>
                </Link>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button size="sm">登录</Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* 主内容 */}
      <main className="container mx-auto px-4 py-12">
        {/* 英雄区域 */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-300 via-pink-300 to-purple-300 bg-clip-text text-transparent">
              跨游戏经济宇宙平台
            </h2>
            <p className="text-lg text-slate-300 max-w-2xl mx-auto mb-6">
              在残梦银河中，每个决策都会影响现实。交易因果资产，参与叙事事件，塑造游戏世界的未来。
            </p>
            {!isAuthenticated && (
              <a href={getLoginUrl()}>
                <Button size="lg" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                  开始冒险
                </Button>
              </a>
            )}
          </div>
        </section>

        {/* 统计卡片 */}
        {isAuthenticated && playerProfileQuery.data && (
          <section className="mb-16">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-800/50 border-purple-500/20 hover:border-purple-500/50 transition-colors">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-purple-400" />
                    影响力评分
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-400">
                    {playerProfileQuery.data.totalInfluenceScore}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-purple-500/20 hover:border-purple-500/50 transition-colors">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-pink-400" />
                    持有资产
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-pink-400">
                    {playerProfileQuery.data.totalAssetsHeld}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-purple-500/20 hover:border-purple-500/50 transition-colors">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-400" />
                    创建资产
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-400">
                    {playerProfileQuery.data.totalAssetsCreated}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-purple-500/20 hover:border-purple-500/50 transition-colors">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                    <Users className="w-4 h-4 text-cyan-400" />
                    参与交易
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-cyan-400">
                    {playerProfileQuery.data.totalTradesParticipated}
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>
        )}

        {/* 游戏节点 */}
        <section>
          <div className="mb-6">
            <h3 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-purple-400" />
              游戏节点网络
            </h3>
            <p className="text-slate-400 mt-2">
              探索残梦银河联邦体中的各个游戏世界，参与经济循环
            </p>
          </div>

          {gameNodesQuery.isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-purple-400" />
            </div>
          ) : gameNodesQuery.data && gameNodesQuery.data.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {gameNodesQuery.data.map((node) => (
                <Link key={node.id} href={`/node/${node.id}`}>
                  <Card className="bg-slate-800/50 border-purple-500/20 hover:border-purple-500/50 transition-all cursor-pointer hover:shadow-lg hover:shadow-purple-500/20">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-purple-300">{node.name}</CardTitle>
                          <CardDescription className="text-slate-400">
                            {node.type === "main" ? "主游戏" : "子游戏"}
                          </CardDescription>
                        </div>
                        {node.type === "main" && (
                          <span className="px-2 py-1 bg-purple-500/20 text-purple-300 text-xs rounded-full">
                            主
                          </span>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-slate-300 mb-4">
                        {node.description || "暂无描述"}
                      </p>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-slate-700/50 p-2 rounded">
                          <div className="text-slate-400">秩序度</div>
                          <div className="text-purple-400 font-semibold">
                            {parseFloat(node.orderLevel as any).toFixed(2)}
                          </div>
                        </div>
                        <div className="bg-slate-700/50 p-2 rounded">
                          <div className="text-slate-400">混沌度</div>
                          <div className="text-pink-400 font-semibold">
                            {parseFloat(node.chaosLevel as any).toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardContent className="py-8 text-center text-slate-400">
                暂无游戏节点
              </CardContent>
            </Card>
          )}
        </section>

        {/* 功能介绍 */}
        <section className="mt-16 py-12 border-t border-purple-500/20">
          <h3 className="text-2xl font-bold text-slate-100 mb-8">核心功能</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-purple-300 flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  因果资产
                </CardTitle>
              </CardHeader>
              <CardContent className="text-slate-300">
                创建和交易代表游戏事件影响权的资产。每个资产都能改变游戏世界的概率分布。
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-pink-300 flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  叙事事件
                </CardTitle>
              </CardHeader>
              <CardContent className="text-slate-300">
                您的每个决策都会生成叙事事件，影响全局概率场，推动游戏世界的演化。
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-cyan-300 flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  治理自迭代
                </CardTitle>
              </CardHeader>
              <CardContent className="text-slate-300">
                参与社区治理，投票决定游戏规则的演化，实现平台的自我进化。
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* 页脚 */}
      <footer className="border-t border-purple-500/20 bg-slate-900/50 mt-16 py-8">
        <div className="container mx-auto px-4 text-center text-slate-400 text-sm">
          <p>残梦银河游戏联邦体 © 2025 | 基于S语言范式构建的跨游戏经济平台</p>
        </div>
      </footer>
    </div>
  );
}
