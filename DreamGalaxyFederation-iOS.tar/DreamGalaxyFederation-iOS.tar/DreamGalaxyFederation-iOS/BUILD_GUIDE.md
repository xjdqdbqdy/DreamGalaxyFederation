# 残梦银河 iOS 构建指南

## 📋 前置要求

- **Xcode** 15.0 或更高版本
- **macOS** 13.0 或更高版本
- **iOS** 14.0 或更高版本（最低部署目标）
- **Apple Developer Account**（用于发布到App Store）

## 🏗️ 项目结构

```
ios/
├── app.json                 # Expo配置
├── Info.plist              # iOS应用配置
├── App.swift               # SwiftUI主应用入口
├── project.pbxproj         # Xcode项目配置
└── BUILD_GUIDE.md          # 本文件
```

## 🚀 构建步骤

### 1. 准备环境

```bash
# 安装Xcode命令行工具
xcode-select --install

# 验证Xcode版本
xcodebuild -version

# 安装CocoaPods（如果需要）
sudo gem install cocoapods
```

### 2. 打开项目

```bash
# 方式1：使用Xcode打开
open ios/DreamGalaxyFederation.xcodeproj

# 方式2：使用命令行
xcode-select -p
```

### 3. 配置签名和证书

在Xcode中：
1. 选择项目 → DreamGalaxyFederation
2. 选择Target → DreamGalaxyFederation
3. 进入 "Signing & Capabilities" 标签
4. 选择您的Team ID
5. 配置Bundle Identifier：`com.dreamgalaxy.federation`

### 4. 构建应用

#### 开发构建

```bash
# 使用Xcode构建
xcodebuild -scheme DreamGalaxyFederation -configuration Debug -destination 'generic/platform=iOS'

# 或在Xcode中：Product → Build
```

#### 发布构建

```bash
# 使用Xcode构建
xcodebuild -scheme DreamGalaxyFederation -configuration Release -destination 'generic/platform=iOS' -archivePath DreamGalaxyFederation.xcarchive archive

# 导出IPA文件
xcodebuild -exportArchive -archivePath DreamGalaxyFederation.xcarchive -exportOptionsPlist ExportOptions.plist -exportPath ./build
```

### 5. 在模拟器上测试

```bash
# 列出可用的模拟器
xcrun simctl list devices

# 构建并运行在模拟器上
xcodebuild -scheme DreamGalaxyFederation -configuration Debug -destination 'platform=iOS Simulator,name=iPhone 15'
```

## 📱 App Store 发布

### 1. 创建App Store Connect应用

1. 访问 https://appstoreconnect.apple.com
2. 点击 "我的App"
3. 点击 "+" 创建新应用
4. 填写应用信息：
   - 名称：残梦银河
   - 主要语言：中文（简体）
   - Bundle ID：com.dreamgalaxy.federation
   - SKU：DreamGalaxyFederation

### 2. 填写应用信息

**应用信息：**
- 类别：游戏 → 角色扮演
- 内容等级：12+
- 隐私政策URL：https://github.com/xjdqdbqdy/DreamGalaxyFederation/blob/main/PRIVACY.md

**应用描述：**
```
跨游戏经济宇宙平台 - 在残梦银河中，每个决策都会影响现实

核心特性：
• 因果资产系统 - 将游戏事件的影响权转化为可交易的数字资产
• 概率场管理 - 全息概率场实现游戏状态的量子叠加与观测坍缩
• 叙事驱动经济 - 玩家行为自动生成叙事事件，推动经济循环
• 跨游戏经济循环 - 主游戏与子游戏间的资产无缝流转
• 社区治理自迭代 - 基于玩家投票的规则动态演化
```

**关键词：**
```
游戏, 经济, 跨游戏, 区块链, 叙事, 概率场, 联邦体
```

### 3. 上传应用

```bash
# 使用Transporter上传IPA
# 1. 下载Transporter: https://apps.apple.com/app/transporter/id1450874784
# 2. 打开Transporter
# 3. 选择IPA文件
# 4. 点击"Deliver"上传
```

或使用命令行：

```bash
# 使用altool（已弃用，推荐使用Transporter）
xcrun altool --upload-app --type ios --file DreamGalaxyFederation.ipa --username your-apple-id@example.com --password your-app-specific-password
```

### 4. 提交审核

1. 在App Store Connect中填写完所有必需信息
2. 选择版本 → 提交以供审核
3. 等待Apple审核（通常需要1-3天）

## 🔐 证书和签名

### 创建开发证书

```bash
# 使用fastlane自动创建证书
gem install fastlane
fastlane init

# 或手动在Apple Developer创建
# https://developer.apple.com/account/resources/certificates/list
```

### 配置签名

在 `Info.plist` 中配置：

```xml
<key>CFBundleIdentifier</key>
<string>com.dreamgalaxy.federation</string>

<key>CFBundleVersion</key>
<string>1</string>

<key>CFBundleShortVersionString</key>
<string>1.0.0</string>
```

## 🐛 常见问题

### 问题1：找不到Xcode
```bash
# 解决方案
sudo xcode-select --switch /Applications/Xcode.app/Contents/Developer
```

### 问题2：签名错误
```bash
# 清除派生数据
rm -rf ~/Library/Developer/Xcode/DerivedData/*

# 重新构建
xcodebuild clean build
```

### 问题3：模拟器启动失败
```bash
# 重置模拟器
xcrun simctl erase all

# 或创建新模拟器
xcrun simctl create "iPhone 15" com.apple.CoreSimulator.SimDeviceType.iPhone-15 com.apple.CoreSimulator.SimRuntime.iOS-17-2
```

### 问题4：网络连接问题
确保在 `Info.plist` 中配置了正确的服务器地址：
```xml
<key>NSExceptionDomains</key>
<dict>
    <key>api.manus.im</key>
    <dict>
        <key>NSIncludesSubdomains</key>
        <true/>
        <key>NSExceptionAllowsInsecureHTTPLoads</key>
        <false/>
    </dict>
</dict>
```

## 📊 应用统计

- **最小iOS版本**: 14.0
- **支持设备**: iPhone, iPad
- **支持方向**: 竖屏, 横屏
- **应用大小**: ~50-100 MB（取决于资源）
- **权限**: 相机, 相册, 网络, 本地网络

## 🔄 更新应用

### 发布新版本

1. 更新 `Info.plist` 中的版本号
2. 重新构建应用
3. 上传新的IPA文件
4. 提交审核

```bash
# 更新版本号
# Info.plist
<key>CFBundleShortVersionString</key>
<string>1.1.0</string>

<key>CFBundleVersion</key>
<string>2</string>
```

## 📚 参考资源

- [Apple Developer Documentation](https://developer.apple.com/documentation/)
- [Xcode Help](https://help.apple.com/xcode/)
- [App Store Connect Help](https://help.apple.com/app-store-connect/)
- [iOS Security](https://www.apple.com/business/site/docs/iOS_Security_Guide.pdf)

## 🎯 下一步

1. ✅ 配置证书和签名
2. ✅ 构建并测试应用
3. ✅ 准备App Store资源（图标、截图、描述）
4. ✅ 提交审核
5. ✅ 发布到App Store

---

**版本**: 1.0.0
**最后更新**: 2025年12月
**支持**: https://help.manus.im
