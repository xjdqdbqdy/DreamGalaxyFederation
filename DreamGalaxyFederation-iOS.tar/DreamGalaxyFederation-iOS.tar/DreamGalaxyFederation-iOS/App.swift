import SwiftUI
import WebKit

@main
struct DreamGalaxyApp: App {
    @State private var webView: WKWebView?
    @State private var isLoading = true
    @State private var showError = false
    @State private var errorMessage = ""
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                // 深紫色背景
                Color(red: 0.12, green: 0.10, blue: 0.29)
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // 导航栏
                    HStack {
                        Text("残梦银河")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        // 返回按钮
                        Button(action: {
                            webView?.goBack()
                        }) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.white)
                        }
                        
                        // 前进按钮
                        Button(action: {
                            webView?.goForward()
                        }) {
                            Image(systemName: "chevron.right")
                                .foregroundColor(.white)
                        }
                        
                        // 刷新按钮
                        Button(action: {
                            webView?.reload()
                        }) {
                            Image(systemName: "arrow.clockwise")
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color(red: 0.10, green: 0.08, blue: 0.25))
                    
                    // WebView容器
                    WebViewContainer(webView: $webView, isLoading: $isLoading, errorMessage: $errorMessage, showError: $showError)
                        .ignoresSafeArea(edges: .bottom)
                    
                    // 加载指示器
                    if isLoading {
                        VStack(spacing: 12) {
                            ProgressView()
                                .tint(Color(red: 0.67, green: 0.34, blue: 0.97))
                            Text("加载中...")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.white)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color(red: 0.12, green: 0.10, blue: 0.29))
                    }
                }
                
                // 错误提示
                if showError {
                    VStack(spacing: 16) {
                        VStack(spacing: 12) {
                            Image(systemName: "exclamationmark.circle.fill")
                                .font(.system(size: 48))
                                .foregroundColor(Color(red: 0.92, green: 0.29, blue: 0.59))
                            
                            Text("加载失败")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                            
                            Text(errorMessage)
                                .font(.system(size: 14, weight: .regular))
                                .foregroundColor(Color(red: 0.89, green: 0.91, blue: 0.94))
                                .multilineTextAlignment(.center)
                        }
                        .padding(24)
                        .background(Color(red: 0.10, green: 0.08, blue: 0.25))
                        .cornerRadius(12)
                        
                        Button(action: {
                            webView?.reload()
                            showError = false
                            isLoading = true
                        }) {
                            Text("重新加载")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color(red: 0.67, green: 0.34, blue: 0.97))
                                .cornerRadius(8)
                        }
                    }
                    .padding(24)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color.black.opacity(0.6))
                }
            }
        }
    }
}

struct WebViewContainer: UIViewRepresentable {
    @Binding var webView: WKWebView?
    @Binding var isLoading: Bool
    @Binding var errorMessage: String
    @Binding var showError: Bool
    
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        
        // 启用JavaScript
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        
        // 配置用户代理
        config.applicationNameForUserAgent = "DreamGalaxyFederation/1.0"
        
        // 启用媒体播放
        config.mediaTypesRequiringUserActionForPlayback = []
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        self.webView = webView
        
        // 加载应用
        if let url = URL(string: "https://3000-ibrc9z1tvi4ux19wluo72-9d7d2fac.manusvm.computer") {
            let request = URLRequest(url: url)
            webView.load(request)
        }
        
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(isLoading: $isLoading, errorMessage: $errorMessage, showError: $showError)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        @Binding var isLoading: Bool
        @Binding var errorMessage: String
        @Binding var showError: Bool
        
        init(isLoading: Binding<Bool>, errorMessage: Binding<String>, showError: Binding<Bool>) {
            self._isLoading = isLoading
            self._errorMessage = errorMessage
            self._showError = showError
        }
        
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            isLoading = true
            showError = false
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            isLoading = false
        }
        
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            isLoading = false
            errorMessage = error.localizedDescription
            showError = true
        }
        
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            isLoading = false
            errorMessage = error.localizedDescription
            showError = true
        }
        
        // 处理JavaScript弹窗
        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            let alert = UIAlertController(title: "残梦银河", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in
                completionHandler()
            })
            
            if let window = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                window.windows.first?.rootViewController?.present(alert, animated: true)
            }
        }
    }
}

#Preview {
    DreamGalaxyApp()
}
